package db;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import models.Film;

import java.sql.*;


public class FilmDAO {
	
	Film oneFilm = null;
	Connection conn = null;
    Statement stmt = null;
	String user = "ibrahema";
    String password = "proghewN9";
    // Note none default port used, 6306 not 3306
    String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/"+user;

	public FilmDAO() {}

	
	private void openConnection(){
		// loading jdbc driver for mysql
		try{
		    Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch(Exception e) { System.out.println(e); }

		// connecting to database
		try{
			// connection string for demos database, username demos, password demos
 			conn = DriverManager.getConnection(url, user, password);
		    stmt = conn.createStatement();
		} catch(SQLException se) { System.out.println(se); }	   
    }
	private void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Film getNextFilm(ResultSet rs){
    	Film thisFilm=null;
		try {
			thisFilm = new Film(
					rs.getInt("id"),
					rs.getString("title"),
					rs.getInt("year"),
					rs.getString("director"),
					rs.getString("stars"),
					rs.getString("review"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return thisFilm;		
	}
	
	
	
   public ArrayList<Film> getAllFilms(){
	   
		ArrayList<Film> allFilms = new ArrayList<Film>();
		openConnection();
		
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    	System.out.println(oneFilm.getTitle());
		    	allFilms.add(oneFilm);
		   }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
   }

   public Film getFilmByID(int id){
	   
		openConnection();
		oneFilm=null;
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from films where id="+id;
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return oneFilm;
   }
   
   
   //Search film by name or title
   public ArrayList<Film>  getFilmByName(String name){
	   
		openConnection();
		ArrayList<Film> allFilms = new ArrayList<Film>();
		oneFilm=null;
		try{
		    String selectSQL = "select * from films where title like '%" + name +"%'";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
		    System.out.println(selectSQL);
		    
		    while(rs1.next()){
		    	oneFilm = getNextFilm(rs1);
		    	allFilms.add(oneFilm);
			    System.out.println(oneFilm.toString());
		    }
		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allFilms;
 }
   
   // inseret contact into database
   
   public int newFilm(Film film){
	   
		openConnection();
		int result = 0;
		String selectSQL = "";
		System.out.println(selectSQL + " --> " );
		try{
		    selectSQL = "insert into films(title,year,director,stars,review) values ('"+ film.getTitle() +"','" + film.getYear() +"','" + film.getDirector() + "','" + film.getStars() + "','"+ film.getReview()+"');"; 
		    result = stmt.executeUpdate(selectSQL);
		    System.out.println(selectSQL + " --> " + result);
		    
		    stmt.close();
		    closeConnection();
			} catch(SQLException se) { System.out.println(se); }

		return result;
  }
   
   // delete film
   public int deleteFilm(Film film){
 	   
		openConnection();
		int result = 0;
		String selectSQL = "";
		try{
		    selectSQL = "DELETE FROM films WHERE id = " + film.getId() + ";"; 
		    result = stmt.executeUpdate(selectSQL);
		    System.out.println(selectSQL + " --> " + result);
		    
			    stmt.close();
			    closeConnection();
			} catch(SQLException se) { System.out.println(se); }
		
		return result;
  }
   
   //update film
   public int updateFilm(Film film){
 	   
		openConnection();
		int result = 0;
		String selectSQL = "";
		try{
		    selectSQL = "UPDATE films SET title = '" + film.getTitle() + "', year = " + film.getYear() + ", director = '" + film.getDirector() + "', stars = '" + film.getStars() + "', review = '" + film.getReview() + "' WHERE id = " + film.getId() + ";"; 
		    result = stmt.executeUpdate(selectSQL);
		    System.out.println(selectSQL + " --> " + result);
		    
		    stmt.close();
		    closeConnection();
			} catch(SQLException se) { System.out.println(se); }

		return result;
}
   
}