package controllers;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import models.Film;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "films")
public class FilmList {

	@XmlElement(name = "film")
private List<Film> filmsList;
public FilmList() {}

public FilmList(List<Film> filmsList) {
this.filmsList = filmsList;
}
public List<Film> getFilmsList() {
return filmsList;
}
public void setFilmList(List<Film> filmsList) {
this.filmsList = filmsList;
}
}
