package controllers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import db.FilmDAO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import models.Film;

/**
 * Servlet implementation class Myrestfulapi
 */
@WebServlet("/Myrestfulapi")
public class Myrestfulapi extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Myrestfulapi() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter(); 		
		response.setContentType("application/json"); //server to client 		 		
		FilmDAO dao = new FilmDAO(); 		 		
		ArrayList<Film> films = dao.getAllFilms(); 		
		String ContentTypeHeader = "";
		ContentTypeHeader = request.getHeader("Content-Type"); //content type header
		
		if(ContentTypeHeader == null) {
			ContentTypeHeader = "text/plain";} //set if null
		
		if(ContentTypeHeader.equals("application/xml")){ //handle application/xml with jaxb library for get request
			FilmList cl = new FilmList(films);
			StringWriter sw = new StringWriter();
			JAXBContext context = null;
			try {
				context = JAXBContext.newInstance(FilmList.class);
				Marshaller m = context.createMarshaller();
				m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
				Boolean.TRUE);
				m.marshal(cl, sw);
				out.print(sw);
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else if(ContentTypeHeader.equals("application/json")){ // handle application/json with gson library for get request
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			String json = gson.toJson(films);
			out.write(json); 
		}
		else if(ContentTypeHeader.equals("text/plain")){ //default text/plain for get request
			String data ="";
			for(int i=0; i<films.size(); i++) {
			data = data + "&"+ films.get(i).getId() + "@" + films.get(i).getTitle() + "@" + films.get(i).getDirector() + "@" + films.get(i).getYear() + "@" + films.get(i).getReview() + "@" + films.get(i).getStars();}
			out.print(data);
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {			
		response.setContentType("application/json"); //server to client 		 		
		FilmDAO dao = new FilmDAO(); 		 			 		
		String ContentTypeHeader = request.getHeader("Content-Type"); //content type header 
		String data = request.getReader().lines().reduce("",(accumulator, actual) -> accumulator + actual);
		if(ContentTypeHeader == null) {
			ContentTypeHeader = "text/plain";} //set if null
		
		if(ContentTypeHeader.equals("application/xml")){//handle application/xml with jaxb library for post request
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(Film.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				Film film = (Film) jaxbUnmarshaller.unmarshal(new StringReader(data));
				dao.newFilm(film);
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(ContentTypeHeader.equals("application/json")){//handle application/json with gson library for post request
			Gson gson = new Gson();
			Film film = gson.fromJson(data, Film.class);  
			dao.newFilm(film);
		}
		else if(ContentTypeHeader.equals("text/plain")){ // handle text/plain for post request 
			BufferedReader reader =new BufferedReader(new StringReader(data));
			String [] dataFilm = null;
			String line;

	        while((line=reader.readLine())!=null){
	        		dataFilm =line.trim().split("@");
	        }
			String Title = dataFilm[0];
			if(Title.contains("&")) {
				Title = Title.substring(1, Title.length());
			}
			String Director = dataFilm[1];
			int Year = Integer.valueOf(dataFilm[2]);
			String Stars = dataFilm[3];
			String Review = dataFilm[4];
			
			Film film1 = new Film();
			film1.setTitle(Title);
			film1.setYear(Year);
			film1.setDirector(Director);
			film1.setStars(Stars);
			film1.setReview(Review);
			dao.newFilm(film1);
		}
			
	}
	
	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { 		
		resp.setContentType("application/json"); //server to client 		 		
		FilmDAO dao = new FilmDAO();	 		
		String ContentTypeHeader = req.getHeader("Content-Type"); //content type header
		String data = req.getReader().lines().reduce("",(accumulator, actual) -> accumulator + actual); 
		if(ContentTypeHeader == null) {
			ContentTypeHeader = "text/plain";} //set if null
		
		if(ContentTypeHeader.equals("application/xml")){ //handle application/xml with jaxb library for put request
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(Film.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				Film film = (Film) jaxbUnmarshaller.unmarshal(new StringReader(data));
				dao.updateFilm(film);
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else if(ContentTypeHeader.equals("application/json")){// handle application/json with gson library for put request
			Gson gson = new Gson();
			Film film = gson.fromJson(data, Film.class);  
			dao.updateFilm(film);
		}
		else if(ContentTypeHeader.equals("text/plain")){// handle text/plain for put request 
			BufferedReader reader =new BufferedReader(new StringReader(data));
			String [] dataFilm = null;
			String line;

	        while((line=reader.readLine())!=null){
	        		dataFilm =line.trim().split("@");
	        }
	        String StringId = dataFilm[0];
	        if(StringId.contains("&")) {
	        	StringId = StringId.substring(1, StringId.length());
			}
			
			int Id = Integer.valueOf(StringId);
			String Title = dataFilm[1];
			String Director = dataFilm[2];
			int Year = Integer.valueOf(dataFilm[3]);
			String Stars = dataFilm[4];
			String Review = dataFilm[5];
			
			Film film1 = new Film();
			film1.setId(Id);
			film1.setTitle(Title);
			film1.setYear(Year);
			film1.setDirector(Director);
			film1.setStars(Stars);
			film1.setReview(Review);
			dao.updateFilm(film1);
		}
	}
	
	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("application/json"); //server to client 		 		
		FilmDAO dao = new FilmDAO();	 		
		String ContentTypeHeader = req.getHeader("Content-Type"); //content type header
		String data = req.getReader().lines().reduce("",(accumulator, actual) -> accumulator + actual);
		if(ContentTypeHeader == null) {
			ContentTypeHeader = "text/plain";} //set set if null
		
		if(ContentTypeHeader.equals("application/xml")){  //handle application/xml with jaxb library for delete request
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(Film.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				Film film = (Film) jaxbUnmarshaller.unmarshal(new StringReader(data));
				dao.deleteFilm(film);
			} catch (JAXBException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			else if(ContentTypeHeader.equals("application/json")){// handle application/json with gson library for delete request
			Gson gson = new Gson();
			Film film = gson.fromJson(data, Film.class);  
			dao.deleteFilm(film);
			}
			else if(ContentTypeHeader.equals("text/plain")){ // handle text/plain for delete request 
			BufferedReader reader =new BufferedReader(new StringReader(data));
			String [] dataFilm = null;
			String line;

	        while((line=reader.readLine())!=null){
	        		dataFilm =line.trim().split("@");
	        }
	        String StringId = dataFilm[0];
	        if(StringId.contains("&")) {
	        	StringId = StringId.substring(1, StringId.length());
			}
			int Id = Integer.valueOf(StringId);
			Film film1 = new Film();
			film1.setId(Id);
			dao.deleteFilm(film1);
		}
	}

}
