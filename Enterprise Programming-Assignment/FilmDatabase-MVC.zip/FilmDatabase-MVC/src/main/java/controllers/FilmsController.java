package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.Film;
import db.FilmDAO;

/**
 * Servlet implementation class Films
 */
@WebServlet("/Films")
public class FilmsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	FilmDAO dao = new FilmDAO();
	ArrayList<Film> films = dao.getAllFilms();
	request.setAttribute("film", films);
	RequestDispatcher rd = request.getRequestDispatcher("film.jsp");
	rd.include(request, response);
	//System.out.println(films);
	}	

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
