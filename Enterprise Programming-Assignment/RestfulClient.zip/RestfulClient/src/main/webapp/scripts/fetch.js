function viewFilm() {
  // Get the value of the selected option
  const format = document.getElementById("response-format").value;

  // Use the fetch API to send a GET request to the API's endpoint for retrieving film information
  fetch(`http://localhost:8080/Myrestfulapi/Myrestfulapi`, {
    headers: {
      "Accept": format === "json" ? "application/json" : format === "xml" ? "application/xml" : "text/plain"
    }
  })
  .then(response => {
    if (response.ok) {
      if (format === "json") {
          return response.json();
      } else if (format === "xml") {
          return response.text();
      } else {
          return response.text();
      }
    } else {
      throw new Error("Error fetching film details");
    }
  })
  .then(film => {
    // Display the film details to the user
    document.getElementById("title").innerHTML = film.title;
    document.getElementById("year").innerHTML = film.year;
    document.getElementById("director").innerHTML = film.director;
    document.getElementById("stars").innerHTML = film.stars;
    document.getElementById("review").innerHTML = film.review;
    
  })
  .catch(error => {
    console.error(error);
  });
}

function insertFilm(film, format) {
  fetch("http://localhost:8080/Myrestfulapi/Myrestfulapi/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept": format === "json" ? "application/json" : format === "xml" ? "application/xml" : "text/plain"
    },
    body: JSON.stringify(film)
  })
  .then(response => {
    if (response.ok) {
      console.log("Film inserted successfully!");
    } else {
      throw new Error("Error inserting film");
    }
  })
  .catch(error => {
    console.error(error);
  });
}

document.getElementById("film-form").addEventListener("submit", function(event) {
  event.preventDefault();
  const film = {
    title: document.getElementById("title").value,
    year: document.getElementById("year").value,
    director: document.getElementById("director").value,
    stars: document.getElementById("stars").value,
    review: document.getElementById("review").value
  };
  const format = document.getElementById("response-format").value;
  insertFilm(film, format);
});


function updateFilm(id, film, format) {
  fetch("http://localhost:8080/Myrestfulapi/Myrestfulapi/films", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "Accept": format === "json" ? "application/json" : format === "xml" ? "application/xml" : "text/plain"
    },
    body: JSON.stringify(film)
  })
  .then(response => {
    if (response.ok) {
      console.log("Film updated successfully!");
    } else {
      throw new Error("Error updating film");
    }
  })
  .catch(error => {
    console.error(error);
  });
}

document.getElementById("film-form").addEventListener("submit", function(event) {
  event.preventDefault();
  const format = document.getElementById("response-format").value;
  const film = {
    title: document.getElementById("title").value,
    year: document.getElementById("year").value,
    director: document.getElementById("director").value,
    stars: document.getElementById("stars").value,
    review: document.getElementById("review").value
    
  };
  const id = document.getElementById("film-id").value;
  updateFilm(id, film, format);
});



function deleteFilm(id) {
  fetch(`http://localhost:8080/Myrestfulapi/Myrestfulapi/films/${id}`, {
    method: "DELETE"
  })
  .then(response => {
    if (response.ok) {
      throw new Error(response.statusText);
    }
    return response.json();
  })
  .then(data => console.log(data))
  .catch(error => {
    console.error(error);
    // display an error message to the user
    alert("An error occurred while deleting the film. Please try again later.");
  });
}

document.getElementById("delete-film-button").addEventListener("click", function(event) {
  const id = document.getElementById("film-id").value;
  const format = document.getElementById("response-format").value;
  deleteFilm(id, format);
});
 
