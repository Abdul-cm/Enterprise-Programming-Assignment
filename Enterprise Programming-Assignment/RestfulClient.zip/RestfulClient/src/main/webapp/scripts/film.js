// Send GET request to "/Myrestfulapi"
fetch("/Myrestfulapi", {
  method: "GET",
  headers: {
    "Content-Type": "application/json" //set the content-type header to application/json
  }
})
.then(response => {
  // Check the "Content-Type" header of the response
  if (response.headers.get("Content-Type").includes("application/json")) {
    // If the "Content-Type" is "application/json", parse the response as JSON
    return response.json();
  } else if (response.headers.get("Content-Type").includes("application/xml")) {
    // If the "Content-Type" is "application/xml", parse the response as XML
    return response.text().then(text => new DOMParser().parseFromString(text, "application/xml"));
  } else {
    // If the "Content-Type" is "text/plain", return the response as text
    return response.text();
  }
})
.then(data => {
  // Handle the response data based on its format
  if (data instanceof Object) {
    console.log("Received JSON data:", data);
  } else if (data instanceof Document) {
    console.log("Received XML data:", data);
  } else {
    console.log("Received plain text data:", data);
  }
})
.catch(error => {
  console.error("Error:", error);
});
// Send POST request to "/Myrestfulapi" to add a new film
fetch("/Myrestfulapi", {
  method: "POST",
  headers: {
    "Content-Type": "application/json" //set the content-type header to application/json
  },
  body: JSON.stringify({
    title: "Film Title",
    year: "2022",
    director: "Director Name",
    stars: "Actor 1, Actor 2, Actor 3",
    review: "Positive"
  })
})
.then(response => response.json())
.then(data => {
  console.log("New film added:", data);
})
.catch(error => {
  console.error("Error:", error);
});

// Send PUT request to "/Myrestfulapi" to update an existing film
fetch("/Myrestfulapi", {
  method: "PUT",
  headers: {
    "Content-Type": "application/json" //set the content-type header to application/json
  },
  body: JSON.stringify({
    id: 1, // id of the film to be updated
    title: "Updated Film Title",
    year: "2022",
    director: "Director Name",
    stars: "Actor 1, Actor 2, Actor 3",
    review: "Positive"
  })
})
.then(response => response.json())
.then(data => {
  console.log("Film updated:", data);
})
.catch(error => {
  console.error("Error:", error);
});

// Send DELETE request to "/Myrestfulapi" to delete a film
fetch("/Myrestfulapi", {
  method: "DELETE",
  headers: {
    "Content-Type": "application/json" //set the content-type header to application/json
  },
  body: JSON.stringify({
    id: 1 // id of the film to be deleted
  })
})
.then(response => response.json())
.then(data => {
  console.log("Film deleted:", data);
})
.catch(error => {
  console.error("Error:", error);
});
