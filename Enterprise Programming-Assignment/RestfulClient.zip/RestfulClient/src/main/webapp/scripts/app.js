      fetch("http://localhost:8080/Myrestfulapi/Myrestfulapi/films")
        .then(response => response.json())
        .then(films => {
          let filmList = document.getElementById("film-list");

          for (let i = 0; i < films.length; i++) {
            let film = films[i];
            let title = film.title;
            let year = film.year;
            let director = film.director;
            let stars = film.stars;
            let review = film.review;

            let filmItem = document.createElement("li");
            filmItem.innerHTML = ` ${title} - ${year} - ${director} - ${stars} - ${review}`;
            filmList.appendChild(filmItem);
          }
        })
        .catch(error => {
          console.error(error);
        });
